public class Main {

    public static void main(String[] args) {
        int resultado =0;
        resultado=suma(4, 5,6);
        System.out.println(String.valueOf(resultado));

        Veh miVeh = new Veh();
        miVeh.SPuerto();
        System.out.println(String.valueOf(miVeh.marca));
    }

    public static int  suma(int a, int b, int c){
        return a+b+c;
    }


}

class Veh {
    public int marca = 4;
    public void SPuerto() {
        this.marca++;

    }

}